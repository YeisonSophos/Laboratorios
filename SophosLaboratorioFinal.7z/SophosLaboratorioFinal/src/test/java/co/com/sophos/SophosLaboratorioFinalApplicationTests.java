package co.com.sophos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SophosLaboratorioFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
