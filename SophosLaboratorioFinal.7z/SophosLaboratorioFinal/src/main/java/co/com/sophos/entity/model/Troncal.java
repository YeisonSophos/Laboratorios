package co.com.sophos.entity.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import java.io.Serializable;

@Entity
@Table(name="Troncal")
public class Troncal implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotBlank
	@Column(name="idTroncal")
	private int idTroncal;
	
	@NotBlank
	@Column(name="codTroncal")
	private String codTroncal;
	
	
	public int getIdTroncal() {
		return idTroncal;
	}
	public void setIdTroncal(int idTroncal) {
		this.idTroncal = idTroncal;
	}

	public String getCodTroncal() {
		return codTroncal;
	}
	public void setCodTroncal(String codTroncal) {
		this.codTroncal = codTroncal;
	}
	
}