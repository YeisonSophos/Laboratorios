package co.com.sophos.entity.model;

import java.util.Date;

public class Estacion {
	private int idStation;
	private String nameStation;
	private String state;
	private Date hourOpen;
	private Date hourClose;
	
	public Estacion(int idStation, String nameStation, String state, Date hourOpen, Date hourClose) {
		super();
		this.idStation = idStation;
		this.nameStation = nameStation;
		this.state = state;
		this.hourOpen = hourOpen;
		this.hourClose = hourClose;
	}
	
	public Estacion() {
		super();
	}

	public int getIdStation() {
		return idStation;
	}
	public void setIdStation(int idStation) {
		this.idStation = idStation;
	}
	
	public String getNameStation() {
		return nameStation;
	}
	public void setNameStation(String nameStation) {
		this.nameStation = nameStation;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public Date getHourOpen() {
		return hourOpen;
	}
	public void setHourOpen(Date hourOpen) {
		this.hourOpen = hourOpen;
	}
	
	public Date getHourClose() {
		return hourClose;
	}
	public void setHourClose(Date hourClose) {
		this.hourClose = hourClose;
	}

	@Override
	public String toString() {
		return "Estacion [idStation=" + idStation + ", nameStation=" + nameStation + ", state=" + state + ", hourOpen="
				+ hourOpen + ", hourClose=" + hourClose + "]";
	}
	
}