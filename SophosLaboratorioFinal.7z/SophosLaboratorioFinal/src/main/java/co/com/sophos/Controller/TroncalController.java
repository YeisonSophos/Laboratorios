package co.com.sophos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import co.com.sophos.dao.ITroncalDao;
import co.com.sophos.entity.model.Troncal;

@RestController
@Controller
public class TroncalController {

	@Autowired
	ITroncalDao troncalService;
	
	@GetMapping (value = "/troncal")
	public List<Troncal> getAllTroncal() {
		return (List<Troncal>) troncalService.findAll();
	}
	/*@GetMapping(path="/troncal", produces = "application/json")
	public List<Troncal> getAllTroncal(){
		return troncalService.getAll();
	}*/
	
	/*@GetMapping (value = "/troncal/{id}")
	public Troncal getOne(@PathVariable(value = "id")int idTroncal) {
		return troncalService.get(idTroncal);
	}
	
	@PostMapping(value = "/troncal")
	public void add(Troncal troncal) {
		troncalService.post(troncal);
	}*/
}