package co.com.sophos.entity.model;

import java.util.Date;

public class Ruta {
	private String codRuta;
	private Date hourOpenRuta;
	private Date hourCloseRuta;
	
	public Ruta() {
		super();
	}
	
	public Ruta(String codRuta, Date hourOpenRuta, Date hourCloseRuta) {
		super();
		this.codRuta = codRuta;
		this.hourOpenRuta = hourOpenRuta;
		this.hourCloseRuta = hourCloseRuta;
	}
	
	public String getCodRuta() {
		return codRuta;
	}
	public void setCodRuta(String codRuta) {
		this.codRuta = codRuta;
	}
	
	public Date getHourOpenRuta() {
		return hourOpenRuta;
	}
	public void setHourOpenRuta(Date hourOpenRuta) {
		this.hourOpenRuta = hourOpenRuta;
	}
	
	public Date getHourCloseRuta() {
		return hourCloseRuta;
	}
	public void setHourCloseRuta(Date hourCloseRuta) {
		this.hourCloseRuta = hourCloseRuta;
	}

	@Override
	public String toString() {
		return "Ruta [codRuta=" + codRuta + ", hourOpenRuta=" + hourOpenRuta + ", hourCloseRuta=" + hourCloseRuta + "]";
	}
	
}