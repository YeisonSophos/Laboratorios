package co.com.sophos.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan({"co.com.sophos.Controller.ITroncalDao"})
//@EntityScan("co.com.sophos.entity.model")
public class SophosLaboratorioFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SophosLaboratorioFinalApplication.class, args);
	}
}